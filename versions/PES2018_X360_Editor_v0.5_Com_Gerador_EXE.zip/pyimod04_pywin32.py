# -*- coding: utf-8 -*-
"""Configuracao de caminhos de busca para DLLs do pywin32."""
import os
import sys

def install():
    pass
