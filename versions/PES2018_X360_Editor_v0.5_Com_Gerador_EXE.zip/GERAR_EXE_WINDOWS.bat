@echo off
:: ========================================================
:: Script de Automatizacao de Compilacao - PES 2018 Editor
:: ========================================================
TITLE Compilador PES 2018 Editor - PyInstaller
COLOR 0B

echo [INFO] A verificar instalacao do Python e PyInstaller...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERRO] Python nao foi encontrado instalado neste computador!
    echo Instale o Python para poder compilar o .exe.
    goto FIM
)

echo [INFO] A instalar/atualizar o PyInstaller para garantir compatibilidade...
pip install --upgrade pyinstaller >nul 2>&1

echo.
echo [INFO] A iniciar a compilacao do script para um unico executavel (.exe)...
echo ------------------------------------------------------------------------

:: Comando principal do PyInstaller para compilar para .exe
pyinstaller --noconsole --onefile pes2018_editor_xbox360_v0_5.py

echo ------------------------------------------------------------------------
if %errorlevel% eq 0 (
    echo [SUCESSO] Compilacao concluida com exito!
    echo [INFO] O seu ficheiro executavel esta disponivel na pasta: \dist\pes2018_editor_xbox360_v0_5.exe
) else (
    echo [ERRO] Ocorreu um problema durante a compilacao.
)

:FIM
echo.
echo Pressione qualquer tecla para fechar esta janela...
pause >nul
