# -*- coding: utf-8 -*-
"""Importadores PEP-302 e PEP-451 para aplicacoes congeladas."""
import sys
import os

class PyiFrozenFinder:
    pass
