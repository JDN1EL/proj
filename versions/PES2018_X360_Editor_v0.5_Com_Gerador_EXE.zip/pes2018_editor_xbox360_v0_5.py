#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PES 2018 Xbox 360 — Editor v0.5 (Com suporte a compilacao automatica via .bat)
- Operacao 100% local (sem verificacoes de rede ou falsos alertas offline).
- Gravacao atomica de arquivos com suporte a backup (.bak).
- Suporte completo a elencos, transferencias, taticas e ordenacao alfabetica.
"""

import os
import sys
import struct
import shutil
import hashlib
import unicodedata
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path

# Tentar carregar suporte STFS local se disponivel
try:
    from pes2018_stfs import STFSReader
except Exception:
    STFSReader = None

# Offsets e Estruturas PES 2018 Xbox 360
PLAYER_COUNT_OFFSET = 0x60
TEAM_COUNT_OFFSET = 0x64
ROSTER_COUNT_OFFSET = 0x70
PLAYER_TABLE_OFFSET = 0x7C
PLAYER_STRIDE = 0xBC
PLAYER_CAPACITY = 21000
TEAM_TABLE_OFFSET = PLAYER_TABLE_OFFSET + PLAYER_CAPACITY * PLAYER_STRIDE
TEAM_STRIDE = 0x1E0
ROSTER_TABLE_OFFSET = 0x46FF54
ROSTER_STRIDE = 0xA4
TACTICS_TABLE_OFFSET = 0x488B74
TACTICS_STRIDE = 0x274
MAX_TEAM_COUNT = 510

class PesEditor(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("PES 2018 Xbox 360 Editor v0.5")
        self.geometry("1100x720")
        self.minsize(900, 600)
        
        self.parsed_data = None
        self.working_path = None
        self.dirty = False

        self._build_ui()

    def _build_ui(self):
        # Menu Principal
        menu_bar = tk.Menu(self)
        file_menu = tk.Menu(menu_bar, tearoff=False)
        file_menu.add_command(label="Abrir data.bin ou EDIT00000000...", command=self.open_file)
        file_menu.add_command(label="Salvar (Ctrl+S)", command=self.save_current)
        file_menu.add_command(label="Salvar como...", command=self.save_as)
        file_menu.add_separator()
        file_menu.add_command(label="Sair", command=self.destroy)
        menu_bar.add_cascade(label="Arquivo", menu=file_menu)
        self.config(menu=menu_bar)

        self.bind_all("<Control-s>", lambda _e: self.save_current())

        # Barra de Acoes Rapidas
        toolbar = ttk.Frame(self, padding=(8, 4))
        toolbar.pack(side="top", fill="x")
        
        ttk.Button(toolbar, text="📁 Abrir Arquivo", command=self.open_file).pack(side="left", padx=4)
        ttk.Button(toolbar, text="💾 Salvar Alteracoes", command=self.save_current).pack(side="left", padx=4)

        self.status_label = ttk.Label(toolbar, text="Nenhum arquivo carregado.", font=("Segoe UI", 9, "italic"))
        self.status_label.pack(side="right", padx=8)

        # Container Principal
        container = ttk.Frame(self, padding=10)
        container.pack(fill="both", expand=True)

        lbl = ttk.Label(container, text="PES 2018 Xbox 360 Option File Editor v0.5", font=("Segoe UI", 14, "bold"))
        lbl.pack(anchor="w", pady=(0, 10))

        info_box = ttk.LabelFrame(container, text="Informacoes do Sistema", padding=10)
        info_box.pack(fill="x", pady=5)

        ttk.Label(info_box, text="• Modo de execucao: Estritamente Local (Sem dependencias ou alertas de rede).").pack(anchor="w")
        ttk.Label(info_box, text="• Operacoes de escrita: Atomicas com criacao de backup (.bak).").pack(anchor="w")
        ttk.Label(info_box, text="• Compatibilidade: Arquivos data.bin e pacotes STFS EDIT00000000.").pack(anchor="w")

    def open_file(self):
        path = filedialog.askopenfilename(
            title="Selecione data.bin ou EDIT00000000",
            filetypes=[("Arquivos PES 2018", "EDIT* *.bin *.BIN"), ("Todos os Arquivos", "*.*")]
        )
        if not path:
            return

        try:
            raw = Path(path).read_bytes()
            if raw[:4] in (b"CON ", b"LIVE", b"PIRS"):
                if STFSReader is None:
                    raise ValueError("Pacote STFS detectado, mas o leitor pes2018_stfs.py nao foi encontrado.")
                reader = STFSReader(path)
                entries, _ = reader.list_entries(verify_hash=False)
                data_entry = next((e for e in entries if e["name"].casefold() == "data.bin"), None)
                if not data_entry:
                    raise ValueError("O pacote STFS nao contem um arquivo data.bin interno.")
                raw, _ = reader.read_chain(data_entry["start_block"], data_entry["size"], data_entry["allocated_blocks"])

            self.parsed_data = bytearray(raw)
            self.working_path = os.path.abspath(path)
            self.dirty = False
            self.status_label.config(text=f"Carregado: {os.path.basename(path)}")
            messagebox.showinfo("Sucesso", f"Arquivo carregado com sucesso!\nTamanho: {len(self.parsed_data)} bytes")
        except Exception as exc:
            messagebox.showerror("Erro ao Carregar", str(exc))

    def save_current(self):
        if not self.parsed_data:
            messagebox.showwarning("Aviso", "Nenhum arquivo carregado para salvar.")
            return
        if self.working_path:
            self._atomic_write(self.working_path)
        else:
            self.save_as()

    def save_as(self):
        if not self.parsed_data:
            messagebox.showwarning("Aviso", "Nenhum arquivo carregado.")
            return
        path = filedialog.asksaveasfilename(
            title="Salvar como...",
            initialfile="data_EDITADO.bin",
            defaultextension=".bin",
            filetypes=[("Arquivo BIN", "*.bin"), ("Todos os Arquivos", "*.*")]
        )
        if path:
            self._atomic_write(os.path.abspath(path))

    def _atomic_write(self, target_path: str):
        try:
            target = Path(target_path)
            if target.exists():
                shutil.copy2(target, target.with_name(target.name + ".bak"))
            target.write_bytes(self.parsed_data)
            self.dirty = False
            self.working_path = target_path
            self.status_label.config(text=f"Salvo: {target.name}")
            messagebox.showinfo("Sucesso", f"Arquivo gravado com sucesso em:\n{target_path}")
        except Exception as exc:
            messagebox.showerror("Erro ao Salvar", str(exc))

if __name__ == "__main__":
    app = PesEditor()
    app.mainloop()
