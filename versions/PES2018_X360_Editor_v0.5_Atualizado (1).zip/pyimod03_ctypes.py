# -*- coding: utf-8 -*-
"""Hooks de carregamento local de DLLs e bibliotecas C-types."""
import os
import sys
import ctypes

def install():
    if not hasattr(sys, '_MEIPASS'):
        return
