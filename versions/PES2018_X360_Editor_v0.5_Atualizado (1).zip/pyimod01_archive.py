# -*- coding: utf-8 -*-
"""Leitor de arquivos Zlib/PYZ para PyInstaller."""
import os
import struct
import zlib
import marshal

class ZlibArchiveReader:
    def __init__(self, filename, start_offset=0, check_pymagic=True):
        self._filename = filename
        self._start_offset = start_offset
        self.toc = {}
