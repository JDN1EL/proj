# -*- coding: utf-8 -*-
"""Configuração de caminhos de busca para DLLs do pywin32."""
import os
import sys

def install():
    pass
