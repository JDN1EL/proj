# Histórico de versões

## v0.4 — usabilidade, ordenação e histórico
- Barra inferior com instruções contextuais para controles clicados.
- Ordenação por múltiplos critérios: uma nova coluna vira principal e preserva as anteriores como desempate.
- Clique repetido na coluna inverte somente sua direção.
- Ordenação persistente após atualização de listas.
- Ícones compactos no canto superior esquerdo para salvar, desfazer e refazer.
- Histórico de até 100 ações, implementado por diferenças binárias para limitar memória.
- Indicador de alterações pendentes e proteção de arquivo original.
- Testes com dois `data.bin` PES 2018 e testes da interface Tk.

## v0.3 — compatibilidade e dados de equipe
- Contagem de equipes/elencos lida do cabeçalho (508/510 testados).
- Recuperação com opção “Carregar mesmo assim” e modo somente leitura quando há riscos.
- Pré-visualização e cópia de configurações de formação/tática.
