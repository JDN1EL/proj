@echo off
setlocal
cd /d "%~dp0"
py -3 --version >nul 2>nul
if errorlevel 1 (
  echo Python 3 nao encontrado. Instale Python 3.10 ou superior com Tcl/Tk.
  pause
  exit /b 1
)
py -3 -m pip show pyinstaller >nul 2>nul
if errorlevel 1 py -3 -m pip install pyinstaller
if errorlevel 1 (echo Falha ao instalar PyInstaller.& pause & exit /b 1)
py -3 -m PyInstaller --noconfirm --clean --onefile --windowed --name PES2018_X360_Editor pes2018_editor_xbox360_v0.4.py
if errorlevel 1 (echo Falha ao gerar EXE.) else (echo EXE criado em dist\PES2018_X360_Editor.exe)
pause
