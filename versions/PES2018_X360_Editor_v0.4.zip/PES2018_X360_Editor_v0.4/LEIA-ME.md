# PES 2018 Xbox 360 — Editor v0.4

## Novidades desta versão

- **Barra contextual inferior:** ao clicar em um controle, mostra uma instrução curta e horizontal explicando sua função, sem abrir pop-ups.
- **Ordenação multicoluna persistente:** clicar em uma nova coluna adiciona esse campo como critério principal e mantém os critérios anteriores como secundários. Clicar novamente em uma coluna já ativa inverte somente a direção dela, sem apagar os demais critérios.
- **Ordenação estável nas listas:** nome em ordem alfabética; ID e camisa em ordem numérica. O estado de ordenação permanece após atualizar a lista, filtrar ou editar dados.
- **Ações no canto superior esquerdo:** ícones compactos para salvar, desfazer e refazer.
- **Histórico:** `Ctrl+Z` desfaz e `Ctrl+Y` refaz. O histórico registra alterações de equipes, jogadores, atributos, elencos, camisas e cópia de modelos.
- **Indicador de alterações pendentes:** mostra quando há dados não salvos. O botão de salvar fica ativo quando existe algo para gravar.
- Salvamento continua sendo feito em uma cópia, com validação posterior e backup automático quando o destino já existe.

## Como usar

1. Instale Python 3.10 ou superior no Windows com o componente Tcl/Tk habilitado.
2. Extraia toda esta pasta.
3. Dê duplo clique em `INICIAR_EDITOR.bat`.
4. Abra um `data.bin` extraído/descriptografado de PES 2018.
5. Faça as alterações. Use `Ctrl+Z`/`Ctrl+Y` para desfazer/refazer.
6. Use o ícone de disquete ou `Ctrl+S` para salvar uma cópia. O original não é sobrescrito.

## Ordenação por múltiplas colunas

Exemplo na lista do elenco:

- Clique em **Jogador**: nome é o primeiro critério.
- Clique em **Camisa**: camisa vira o critério principal e nome continua como desempate.
- Clique em **ID**: ID vira o principal; camisa e nome continuam como critérios seguintes.
- Clique novamente em **ID**: somente a direção do ID é invertida; camisa e nome permanecem ativos.

Os cabeçalhos mostram seta e prioridade (`▲1`, `▼2` etc.).

## Testes

Valide os dois arquivos PES 2018 já conhecidos ou quaisquer variantes compatíveis:

```powershell
python testar_editor_PES2018_v0.4.py "C:\caminho\data-console.bin" "C:\caminho\data-modificado.bin"
```

Os testes verificam as contagens, vínculo por ID, elencos, táticas, leitura e gravação estrutural, recuperação e ordenação multicoluna.

Para testar também a interface, a ordenação visual, a barra de ajuda e o histórico (é necessário ambiente gráfico):

```powershell
python testar_interface_PES2018_v0.4.py "C:\caminho\data-console.bin"
```

Esse teste faz alterações temporárias somente em memória, desfaz/refaz e confirma que o conteúdo volta a ficar idêntico ao original. Não grava o `data.bin`.

## Limitações mantidas

- O programa trabalha com `data.bin` já extraído/descriptografado. Não abre diretamente o pacote `EDIT00000000`, não descriptografa, reempacota nem assina saves Xbox 360.
- A integração STFS/CON continua reservada para a etapa posterior ao teste no console.
- Formações e táticas são exibidas em pré-visualização e podem ser copiadas como modelo; não há edição manual de posições táticas nesta versão.
- A aparência do jogador segue em inspeção bruta, sem gravação de subcampos desconhecidos.
- Compatibilidade é para variantes PES 2018 que mantenham o layout conhecido, não para todos os anos/jogos PES.

## Atalhos

| Atalho | Ação |
|---|---|
| `Ctrl+S` | Salvar cópia editada |
| `Ctrl+Z` | Desfazer última alteração |
| `Ctrl+Y` | Refazer alteração desfeita |
| `Ctrl+Shift+Z` | Refazer (alternativo) |
