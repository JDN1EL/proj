@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 "%~dp0pes2018_editor_xbox360_v0.4.py" %*
) else (
  python "%~dp0pes2018_editor_xbox360_v0.4.py" %*
)
if errorlevel 1 pause
